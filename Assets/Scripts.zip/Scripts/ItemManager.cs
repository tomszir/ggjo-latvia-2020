using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemManager : MonoBehaviour
{
  public List<ItemData> items;

  public ItemData currentDraggedItem;
  public int currentDraggedItemSlot;
  public string currentDraggedItemType;

  public GameObject equippedWeapon;

  void Awake()
  {
    BuildItems();
  }

  void BuildItems()
  {
    items = new List<ItemData>() {
      new ItemData(
        ItemData.Type.ITEM, 
        "cheese", 
        "Cheese", 
        "Eat this and you'll be a god.", 
        new Dictionary<string, float[]>(),
        new Dictionary<string, string>()),
        
      new ItemData(
        ItemData.Type.HEADGEAR, 
        "magic_hat", 
        "Magic Hat", 
        "This one will blow your socks off (if you had any).", 
        new Dictionary<string, float[]>() {
          { ItemData.Modifier.MOVE_SPEED, new float[2] { 0.0f, .5f } },
        },
        new Dictionary<string, string>()),

      new ItemData(
        ItemData.Type.WEAPON, 
        "chair_leg", 
        "Chair Leg",  
        "Can't afford a chair, so atleast there's a chair leg.", 
        new Dictionary<string, float[]>() {
          { ItemData.Modifier.DAMAGE, new float[2] { .5f, 0.0f } },
          { ItemData.Modifier.ATTACK_SPEED, new float[2] { 0.5f, 0.0f } },
        },
        new Dictionary<string, string>() {
          { "HIT_SOUND_1", "Sounds/ChairBonk/Explosion_02" },
          { "HIT_SOUND_2", "Sounds/ChairBonk/Explosion_03" },
          { "HIT_SOUND_3", "Sounds/ChairBonk/Explosion_04" }
        }),

      new ItemData(
        ItemData.Type.WEAPON, 
        "bow", 
        "Bow",  
        "Shoots arrows, that's about it.", 
        new Dictionary<string, float[]>() {
          { ItemData.Modifier.DAMAGE, new float[2] { .45f, 0.0f } },
          { ItemData.Modifier.ATTACK_SPEED, new float[2] { .5f, 0.0f } },
          { ItemData.Modifier.MOVE_SPEED, new float[2] { 0.0f, -.3f } },
        },
        new Dictionary<string, string>() {
          { "HIT_SOUND_1", "Sounds/BowShot/Menu_Navigate_03" },
          { "HIT_SOUND_2", "Sounds/BowShot/Hit_00" }
        }),

      new ItemData(
        ItemData.Type.WEAPON, 
        "magic_wand", 
        "Magic Wand",  
        "Firebolt!", 
        new Dictionary<string, float[]>() {
          { ItemData.Modifier.DAMAGE, new float[2] { 2.0f, 0.0f } },
          { ItemData.Modifier.ATTACK_SPEED, new float[2] { 1.25f, 0.0f } },
          { ItemData.Modifier.MOVE_SPEED, new float[2] { 0.0f, -.5f } },
        },
        new Dictionary<string, string>() {
          { "HIT_SOUND_1", "Sounds/MagicWandHit/Shoot_00" },
          { "HIT_SOUND_2", "Sounds/MagicWandHit/Shoot_01" },
          { "HIT_SOUND_3", "Sounds/MagicWandHit/Shoot_02" },
          { "HIT_SOUND_4", "Sounds/MagicWandHit/Shoot_03" }
        }),
    };
  }

  public ItemData GetItem(string id) {
    return items.Find(item => item.id == id);
  }
}
