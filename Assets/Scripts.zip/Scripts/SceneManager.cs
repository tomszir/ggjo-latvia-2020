using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class SceneManager : MonoBehaviour
{
    public Transform player;
    public Transform projectiles;
    public Transform cam;
    public Transform enemies;
    public AudioClip winSound;
    private bool win = false;
    void Start(){
        player = GameObject.FindGameObjectWithTag("Player").transform;
        projectiles = GameObject.FindGameObjectWithTag("Projectiles").transform;
        cam = GameObject.FindGameObjectWithTag("MainCamera").transform;
        enemies = GameObject.FindGameObjectWithTag("Enemies").transform;
    }

    void Update(){
        if(enemies.childCount <= 1 && !win) {
            StartCoroutine(TurnUp());
            win = true;
        }
    }

    public void Died() {
        StartCoroutine(TurnDown());
    }

    public IEnumerator TurnDown(){
        ColorAdjustments b;
        for(int i = 0; i < 10; i++) {
            cam.GetComponent<Volume>().profile.TryGet(out b);
            if(b) b.saturation.value = -10f * (i+1);
            GetComponent<AudioSource>().pitch = .04f * (i+1);
            yield return new WaitForSecondsRealtime(.1f);
        }
        yield return new WaitForSecondsRealtime(5f);
        Application.Quit();
    }

    public IEnumerator TurnUp(){
        Bloom b;
        PaniniProjection p;
        cam.GetComponent<Volume>().profile.TryGet(out b);
        cam.GetComponent<Volume>().profile.TryGet(out p);
        for(int i = 0; i < 80; i++) {
            if(b) b.intensity.value = .1f * (i+1);
            if(p) p.distance.value = .01f * (i+1);
            GetComponent<AudioSource>().pitch += .001f * (i+1);
            yield return new WaitForSecondsRealtime(.01f);
        }
        Application.Quit();
    }
}
